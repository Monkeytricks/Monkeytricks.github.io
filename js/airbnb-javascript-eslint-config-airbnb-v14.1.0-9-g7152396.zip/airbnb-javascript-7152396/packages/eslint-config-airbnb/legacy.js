module.exports = {
  extends: ['eslint-config-airbnb-base/legacy'].map(require.resolve),
  rules: {},
};
